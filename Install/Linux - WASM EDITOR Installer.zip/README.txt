To install the WASM Video Editor on Linux, first move this entire folder to your preferred permanent location (such as your Documents or dedicated Apps folder).

Step 1:
Right-click anywhere inside the folder and choose the "Open in Terminal"
option.

Step 2:
Write "bash install.sh" to install it in an isolated window powered by the default Brave browser.

Step 3:
After it's finished, check to see 2 desktop files for the video editor, the regualar "WASM Video Editor" & "SAFEMODE WASM Video Editor"


HOW TO REMOVE ALL INSTALLED FILES?
1. Open terminal in this folder again.
2. Type:bash unnstall.sh
3. Hit Enter
4. You can now delete this folder or keep it if you want to reinstall later.

📄 License
This project is licensed under the MIT License - see the LICENSE file in the repository for details.

MORE INFORMATION:

WHY IS THERE A SAFE MODE VARIANT?
If an extension causes instability, the safemode variant appends "?safemode=true" or "#safemode=true" to the editor's URL. The editor will execute a sterile boot, bypassing all IndexedDB extensions so you can safely access the Extension Manager to uninstall faulty modules. Afterwhich you canclose it and go back to the regular mode.
