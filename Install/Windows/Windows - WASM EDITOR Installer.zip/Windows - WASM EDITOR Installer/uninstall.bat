@echo off
echo ----------------------------------------
echo Forge: WASM Video Editor Uninstaller
echo ----------------------------------------
echo This will remove:
echo   - Desktop shortcut: WASM Video Editor
echo   - Desktop shortcut: SAFEMODE WASM Video Editor
echo.
set /p "confirm=Continue? (Y/N): "
if /i not "%confirm:~0,1%"=="Y" (
    echo Uninstall cancelled.
    timeout /t 2 >nul
    exit /b
)

del /f /q "%USERPROFILE%\Desktop\WASM Video Editor.lnk" 2>nul
del /f /q "%USERPROFILE%\Desktop\SAFEMODE WASM Video Editor.lnk" 2>nul
echo Shortcuts removed.

set /p "clean=Do you also want to delete the shared sandboxed browser data (IndexedDB, cache, settings)? (Y/N): "
if /i "%clean:~0,1%"=="Y" (
    rd /s /q "%LocalAppData%\WASMEditor" 2>nul
    echo Sandboxed data folder deleted.
) else (
    echo Data folder kept. You can manually delete it at:
    echo   %LocalAppData%\WASMEditor
)

echo.
echo To also delete icons and scripts, just remove this whole folder.
echo Closing in 2 seconds...
timeout /t 2 >nul
