# Forge Wallpaper Rotator (Sticky Edition – overrides Windows slideshow)
$ErrorActionPreference = "SilentlyContinue"
$manifestUrl = "https://raw.githubusercontent.com/Cleo876/wasm-video-editor/refs/heads/main/Wallpaper/wallpaper-manifest.json"
$cacheDir = "$env:APPDATA\ForgeWallpapers\cache"
$manifestCache = "$env:APPDATA\ForgeWallpapers\manifest.json"
$brandedRatio = 0.6

if (-not (Test-Path $cacheDir)) { New-Item -ItemType Directory -Path $cacheDir -Force | Out-Null }

# Force wallpaper style to "Fill" and disable tiling – necessary to defeat Windows Spotlight
function Set-WallpaperStyle {
    $regPath = "HKCU:\Control Panel\Desktop"
    Set-ItemProperty -Path $regPath -Name WallpaperStyle -Value "10" -Force
    Set-ItemProperty -Path $regPath -Name TileWallpaper -Value "0" -Force
}

function Get-Manifest {
    try {
        $m = Invoke-RestMethod -Uri $manifestUrl -TimeoutSec 10
        $m | ConvertTo-Json | Set-Content $manifestCache -Force
        return $m
    } catch {
        if (Test-Path $manifestCache) {
            return Get-Content $manifestCache | ConvertFrom-Json
        }
        return $null
    }
}

function Get-RandomWallpaper($manifest) {
    if (-not $manifest -or -not $manifest.wallpapers) { return $null }
    $wallpapers = $manifest.wallpapers
    $branded = @($wallpapers | Where-Object { $_.type -eq "branded" })
    $neutral = @($wallpapers | Where-Object { $_.type -eq "neutral" })
    $pool = if ((Get-Random -Maximum 100) -lt ($brandedRatio * 100)) { $branded } else { $neutral }
    if (-not $pool -or $pool.Count -eq 0) { $pool = $wallpapers }
    return $pool | Get-Random
}

function Get-LocalImage($url) {
    $name = Split-Path $url -Leaf
    $local = Join-Path $cacheDir $name
    if (-not (Test-Path $local)) {
        try { Invoke-WebRequest -Uri $url -OutFile $local -TimeoutSec 15 } catch { return $null }
    }
    return $local
}

# ---- Main loop (20‑25 min) ----
Write-Output "Forge Wallpaper Rotator started."
while ($true) {
    $manifest = Get-Manifest
    $choice = Get-RandomWallpaper $manifest
    if ($choice) {
        $imagePath = Get-LocalImage $choice.url
        if ($imagePath) {
            # Force the style every time to prevent slideshow from reverting
            Set-WallpaperStyle

            # Apply the wallpaper – SPIF_UPDATEINIFILE (0x01) + SPIF_SENDCHANGE (0x02)
            Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class Wallpaper {
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@
            [Wallpaper]::SystemParametersInfo(0x0014, 0, $imagePath, 0x0003)
        }
    }

    $sleepSeconds = Get-Random -Minimum 1200 -Maximum 1501
    Start-Sleep -Seconds $sleepSeconds
}
