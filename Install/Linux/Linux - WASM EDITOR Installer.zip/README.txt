===================================================================
                WASM Video Editor — Linux Edition
===================================================================

Everything you need is already in this folder.
Installation takes three quick steps.

_______________________________________________________
📁 BEFORE YOU INSTALL
_______________________________________________________

1. Move this entire folder to a permanent location you
   won't accidentally delete (Documents, a dedicated
   Apps folder, ~/.local/share, etc.).

   IMPORTANT: Keep the folder here after installation.
   Moving it later will break the launchers.

_______________________________________________________
⚙️ HOW TO INSTALL
_______________________________________________________

1. Right‑click anywhere inside this folder and choose
   "Open in Terminal".

2. In the terminal, type:

       bash install.sh

   and press Enter.

   The script will create two sandboxed desktop launchers
   powered by the Brave browser (or whichever chromium 
   browser you have installed). Both launchers share the
   same project data but launch in different modes.

3. When it finishes, check your desktop or applications
   menu. You should see:

   →  WASM Video Editor
   →  SAFEMODE WASM Video Editor

   Double‑click either one to start editing.

_______________________________________________________
❓ WHY IS THERE A SAFE MODE?
_______________________________________________________

Safe Mode starts the editor with all extensions temporarily
disabled. If a faulty extension ever causes instability,
open the SAFEMODE launcher. The editor will run a clean
session, bypassing all IndexedDB extensions so you can
safely open the Extension Manager and remove the problem
module. After that, close Safe Mode and return to the
standard launcher — everything works again.

_______________________________________________________
🗑️ HOW TO UNINSTALL
_______________________________________________________

1. Open a terminal inside this folder again (right‑click
   → "Open in Terminal").

2. Type:

       bash uninstall.sh

   and press Enter.

3. The script will remove the desktop launchers.

4. You can now delete this folder, or keep it around if
   you think you might reinstall later.

_______________________________________________________
📄 LICENSE
_______________________________________________________

This project is licensed under the MIT License.
See the LICENSE file in the repository for details.

===================================================================
  Happy editing!  — The Forge Team
===================================================================
