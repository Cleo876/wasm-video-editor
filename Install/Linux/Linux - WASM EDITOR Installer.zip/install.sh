#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# Define the file names
APP="WebApp-WASMVideoEditor0073.desktop"
SAFE_APP="SAFE-WebApp-WASMVideoEditor0073.desktop"

echo "----------------------------------------"
echo "Forge: Detecting Compatible System Engine..."

# 1. Search for the "Clean" Chromium browsers
BROWSER=""
for b in brave-browser google-chrome-stable google-chrome chromium-browser chromium microsoft-edge-stable; do
    if command -v "$b" >/dev/null 2>&1; then
        BROWSER="$b"
        break
    fi
done

# 2. Fallback: install Chromium if none found
if [ -z "$BROWSER" ]; then
    echo "No compatible sandbox engines found (Brave/Chrome/Edge)."
    echo "Installing pure Chromium engine for the Forge Editor..."
    sudo apt update
    sudo apt install chromium-browser -y
    BROWSER="chromium-browser"
else
    echo "Engine Found: $BROWSER"
fi

echo "Installing WASM Editor Modes..."
echo "----------------------------------------"

# Build the common Exec command (maximized window + GPU flags)
# Note: using `--start-maximized` (not fullscreen) and our two GPU flags.
BASE_CMD="sh -c '$BROWSER --start-maximized --ignore-gpu-blocklist --enable-gpu-rasterization --app=\"http://cleo876.github.io/wasm-video-editor\" --user-data-dir=\"\$HOME/.local/share/wasm-editor-shared-data\" --class=WebApp-WASMVideoEditor0073 --name=WebApp-WASMVideoEditor0073'"
SAFE_BASE_CMD="sh -c '$BROWSER --start-maximized --ignore-gpu-blocklist --enable-gpu-rasterization --app=\"http://cleo876.github.io/wasm-video-editor#safemode=true\" --user-data-dir=\"\$HOME/.local/share/wasm-editor-shared-data\" --class=WebApp-WASMVideoEditor0073 --name=WebApp-WASMVideoEditor0073'"

# --- Configure & Install Standard App ---
# Replace the entire Exec line with our clean version
sed -i "s|^Exec=.*|Exec=$BASE_CMD|" "$APP"
sed -i "s|Icon=.*|Icon=$DIR/layer.png|g" "$APP"
chmod +x "$APP"
cp "$APP" ~/Desktop/
cp "$APP" ~/.local/share/applications/

# --- Configure & Install Safe Mode App ---
sed -i "s|^Exec=.*|Exec=$SAFE_BASE_CMD|" "$SAFE_APP"
sed -i "s|Icon=.*|Icon=$DIR/safe-layers.png|g" "$SAFE_APP"
chmod +x "$SAFE_APP"
cp "$SAFE_APP" ~/Desktop/
cp "$SAFE_APP" ~/.local/share/applications/

# Trust both files on the desktop for Zorin/GNOME
gio set ~/Desktop/"$APP" metadata::trusted true
gio set ~/Desktop/"$SAFE_APP" metadata::trusted true

echo "Success! Standard and Safe Mode are ready (maximized window)."
echo "Closing in 2 seconds..."
sleep 2

# Snap the terminal shut
kill -9 $PPID
