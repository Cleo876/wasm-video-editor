#!/bin/bash
APP="WebApp-WASMVideoEditor0073.desktop"
SAFE_APP="SAFE-WebApp-WASMVideoEditor0073.desktop"

echo "Removing WASM Editor Modes..."

# Remove Standard
rm ~/Desktop/$APP 2>/dev/null
rm ~/.local/share/applications/$APP 2>/dev/null

# Remove Safe Mode
rm ~/Desktop/$SAFE_APP 2>/dev/null
rm ~/.local/share/applications/$SAFE_APP 2>/dev/null

echo "Uninstallation complete. All shortcuts removed."
sleep 2
