#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# Define the two file names
APP="WebApp-WASMVideoEditor0073.desktop"
SAFE_APP="SAFE-WebApp-WASMVideoEditor0073.desktop"

echo "Installing WASM Editor Modes..."

# --- Configure Standard App ---
sed -i "s|Icon=.*|Icon=$DIR/layer.png|g" $APP
chmod +x $APP
cp $APP ~/Desktop/
cp $APP ~/.local/share/applications/

# --- Configure Safe Mode App ---
sed -i "s|Icon=.*|Icon=$DIR/safe-layers.png|g" $SAFE_APP
chmod +x $SAFE_APP
cp $SAFE_APP ~/Desktop/
cp $SAFE_APP ~/.local/share/applications/

# Trust both files on the desktop
gio set ~/Desktop/$APP metadata::trusted true
gio set ~/Desktop/$SAFE_APP metadata::trusted true

echo "========================================"
echo "Success! Both Standard and Safe Mode are installed."
echo "========================================"
sleep 2
